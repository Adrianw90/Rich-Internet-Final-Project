// Provide functionality for navbar toggler
